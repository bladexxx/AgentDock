---
name: {{ skill_name }}
description: {{ skill_description }}
---

# CLI-Anything Sand3D

{{ skill_intro }}

## Requirements

Use a Linux Python environment with upstream Sand3D, `bpy`, and this CLI installed. The CLI is a stateless one-shot wrapper around Sand3D's documented bracket recipe.

## Command

```bash
cli-anything-sand3d bracket
cli-anything-sand3d --json bracket --output /tmp/bracket.glb
```

Default output is `./bracket.glb`. The output directory must exist. Optional dimensions in millimetres: `--width` (80), `--depth` (40), `--thickness` (6), `--hole-diameter` (6.6), and `--pitch` (50). Sand3D exports geometry in metres.

## Commands

{% for group in command_groups %}{% for command in group.commands %}- `{{ command.name }}`: {{ command.description }}
{% endfor %}{% endfor %}
## Agent use

Place `--json` before `bracket`. On success, parse `output`, `format`, `bytes`, and `dimensions_mm`; check that the output GLB exists. On failure, use the nonzero exit status and stderr. The CLI uses upstream `s3d.extrude`, `rect`, `hole`, `grid`, `fillet`, and `export`; it has no session, REPL, or preview commands.

Version: {{ version }}.

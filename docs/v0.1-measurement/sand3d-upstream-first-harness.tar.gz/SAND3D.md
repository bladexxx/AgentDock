# Sand3D harness: bracket export

## Source analysis

- Target: `../docs/examples/bracket.py`, mirrored in the upstream README.
- Backend: the installed `sand3d` Python package and its `bpy` dependency. No separate Sand3D executable is needed.
- Geometry: `s3d.extrude("plate", s3d.rect(w, d, r=4), t)`, then `s3d.hole(plate, hole_d, on=s3d.grid(2, 1, pitch, 0))`, then `s3d.fillet(plate, 1, edges="top")`.
- Defaults: width 80, depth 40, thickness 6, hole diameter 6.6, pitch 50; Sand3D treats these as millimetres.
- Export: `s3d.export(plate, path)` supports `.glb` and calls Blender's glTF exporter. The resulting GLB uses metres.

## CLI mapping

`cli-anything-sand3d bracket` runs the upstream recipe once in a fresh process and writes `./bracket.glb` unless `--output` is given. `--json` reports the resolved output path, format, byte count, and input dimensions. There is no project or session file. The CLI validates the GLB header and size after export.

## Paired generation

The repository-local skill at `skills/cli-anything-sand3d/SKILL.md` and packaged skill at `cli_anything/sand3d/skills/SKILL.md` are generated together by the upstream `skill_generator.py` using this harness's `skill-template.md`. Both copies must match.

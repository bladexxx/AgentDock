# CLI-Anything Sand3D

A small, one-shot CLI that builds the [upstream bracket example](../../../../docs/examples/bracket.py) with Sand3D and exports a real GLB. Dimensions are millimetres; the exported geometry uses metres.

## Requirements and installation

Use a Linux Python environment with the upstream Sand3D and its `bpy` dependency available. Install the harness from this `agent-harness` directory with `pip install -e .` after preparing the upstream environment. The console command is `cli-anything-sand3d`; `python -m cli_anything.sand3d` also works.

## Usage

```bash
cli-anything-sand3d bracket
cli-anything-sand3d --json bracket --output /tmp/bracket.glb
cli-anything-sand3d bracket --width 80 --depth 40 --thickness 6 --hole-diameter 6.6 --pitch 50
```

The default output is `./bracket.glb`. The output directory must already exist. `--json` precedes `bracket` and returns `output`, `format`, `bytes`, and `dimensions_mm`. Failures exit nonzero and print an error to stderr.

## Runtime verification after packaging

Run `CLI_ANYTHING_FORCE_INSTALLED=1 python -m pytest cli_anything/sand3d/tests -v -s` in the prepared Linux environment. This generates a GLB through the installed CLI and checks its header and embedded JSON. These checks are deferred during paired generation.

"""One-shot CLI for the Sand3D bracket example."""

import json
from pathlib import Path

import click

from cli_anything.sand3d.core.bracket import export_bracket


@click.group()
@click.option("--json", "json_output", is_flag=True, help="Print a JSON summary.")
@click.pass_context
def cli(ctx, json_output):
    """Export the upstream Sand3D bracket example as a GLB."""
    ctx.ensure_object(dict)
    ctx.obj["json_output"] = json_output


@cli.command()
@click.option("-o", "--output", type=click.Path(dir_okay=False, path_type=Path),
              default=Path("bracket.glb"), show_default=True, help="Destination GLB path.")
@click.option("--width", type=float, default=80.0, show_default=True, help="Plate width in mm.")
@click.option("--depth", type=float, default=40.0, show_default=True, help="Plate depth in mm.")
@click.option("--thickness", type=float, default=6.0, show_default=True, help="Plate thickness in mm.")
@click.option("--hole-diameter", type=float, default=6.6, show_default=True, help="Hole diameter in mm.")
@click.option("--pitch", type=float, default=50.0, show_default=True, help="Hole centre pitch in mm.")
@click.pass_context
def bracket(ctx, output, width, depth, thickness, hole_diameter, pitch):
    """Build the documented two-hole bracket and export a real GLB."""
    if min(width, depth, thickness, hole_diameter, pitch) <= 0:
        raise click.UsageError("all dimensions must be positive")
    try:
        result = export_bracket(output, width, depth, thickness, hole_diameter, pitch)
    except (ImportError, OSError, ValueError, RuntimeError) as exc:
        raise click.ClickException(str(exc)) from exc
    if ctx.obj["json_output"]:
        click.echo(json.dumps(result, sort_keys=True))
    else:
        click.echo(f"Exported {result['output']} ({result['bytes']} bytes)")


if __name__ == "__main__":
    cli()

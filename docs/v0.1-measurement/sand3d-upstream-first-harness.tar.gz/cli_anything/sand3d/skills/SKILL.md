---
name: cli-anything-sand3d
description: Command-line interface for Sand3D - A small, one-shot CLI that builds the [upstream bracket example](../../../../docs/examples/bracket.p...
---

# CLI-Anything Sand3D

A small, one-shot CLI that builds the [upstream bracket example](../../../../docs/examples/bracket.py) with Sand3D and exports a real GLB. Dimensions are millimetres; the exported geometry uses metres.

## Requirements

Use a Linux Python environment with upstream Sand3D, `bpy`, and this CLI installed. The CLI is a stateless one-shot wrapper around Sand3D's documented bracket recipe.

## Command

```bash
cli-anything-sand3d bracket
cli-anything-sand3d --json bracket --output /tmp/bracket.glb
```

Default output is `./bracket.glb`. The output directory must exist. Optional dimensions in millimetres: `--width` (80), `--depth` (40), `--thickness` (6), `--hole-diameter` (6.6), and `--pitch` (50). Sand3D exports geometry in metres.

## Commands

- `bracket`: Build the documented two-hole bracket and export a real GLB.

## Agent use

Place `--json` before `bracket`. On success, parse `output`, `format`, `bytes`, and `dimensions_mm`; check that the output GLB exists. On failure, use the nonzero exit status and stderr. The CLI uses upstream `s3d.extrude`, `rect`, `hole`, `grid`, `fillet`, and `export`; it has no session, REPL, or preview commands.

Version: 0.1.0.
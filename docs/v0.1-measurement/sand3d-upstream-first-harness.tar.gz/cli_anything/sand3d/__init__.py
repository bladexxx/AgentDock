"""CLI-Anything adapter for the upstream Sand3D bracket example."""

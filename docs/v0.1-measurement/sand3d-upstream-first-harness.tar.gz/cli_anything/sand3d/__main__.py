from .sand3d_cli import cli


if __name__ == "__main__":
    cli()

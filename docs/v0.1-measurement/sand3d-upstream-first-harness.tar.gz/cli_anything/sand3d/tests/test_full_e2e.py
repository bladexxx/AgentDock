"""Runtime checks for the outer Linux packaging workflow."""

import json
import os
import shutil
import struct
import subprocess
import sys


def _resolve_cli(name):
    """Prefer the installed command; require it in release validation."""
    path = shutil.which(name)
    if path:
        return [path]
    if os.environ.get("CLI_ANYTHING_FORCE_INSTALLED", "").strip() == "1":
        raise RuntimeError(f"{name} not found in PATH; install the harness first")
    return [sys.executable, "-m", "cli_anything.sand3d"]


class TestCLISubprocess:
    CLI_BASE = _resolve_cli("cli-anything-sand3d")

    def test_help(self):
        result = subprocess.run(self.CLI_BASE + ["--help"], capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        assert "bracket" in result.stdout

    def test_bracket_json_glb(self, tmp_path):
        output = tmp_path / "bracket.glb"
        result = subprocess.run(
            self.CLI_BASE + ["--json", "bracket", "--output", str(output)],
            capture_output=True, text=True,
        )
        assert result.returncode == 0, result.stderr
        summary = json.loads(result.stdout)
        data = output.read_bytes()
        assert summary["output"] == str(output.resolve())
        assert summary["format"] == "glb"
        assert summary["bytes"] == len(data)
        assert summary["dimensions_mm"] == {
            "width": 80, "depth": 40, "thickness": 6,
            "hole_diameter": 6.6, "pitch": 50,
        }
        assert len(data) > 20
        assert struct.unpack("<4sII", data[:12]) == (b"glTF", 2, len(data))
        chunk_length, chunk_type = struct.unpack("<I4s", data[12:20])
        assert chunk_type == b"JSON"
        document = json.loads(data[20:20 + chunk_length])
        assert document["asset"]["version"] == "2.0"
        assert document.get("meshes")
        print(f"GLB: {output} ({len(data):,} bytes)")

"""Recipe and validation checks without loading the upstream backend."""

import struct
import sys
from types import SimpleNamespace

import pytest

from cli_anything.sand3d.core.bracket import export_bracket


def test_recipe_follows_upstream_calls(monkeypatch, tmp_path):
    calls = []
    plate = object()

    def rect(w, d, r):
        calls.append(("rect", w, d, r))
        return "profile"

    def extrude(name, profile, t):
        calls.append(("extrude", name, profile, t))
        return plate

    def grid(x, y, pitch_x, pitch_y):
        calls.append(("grid", x, y, pitch_x, pitch_y))
        return "holes"

    def hole(target, diameter, on):
        calls.append(("hole", target, diameter, on))

    def fillet(target, radius, edges):
        calls.append(("fillet", target, radius, edges))

    def export(target, path):
        calls.append(("export", target, path))
        with open(path, "wb") as f:
            f.write(struct.pack("<4sII", b"glTF", 2, 24) + b"\x00" * 12)

    monkeypatch.setitem(sys.modules, "sand3d", SimpleNamespace(
        rect=rect, extrude=extrude, grid=grid, hole=hole,
        fillet=fillet, export=export,
    ))
    output = tmp_path / "bracket.glb"
    result = export_bracket(output, 80, 40, 6, 6.6, 50)
    assert [call[0] for call in calls] == [
        "rect", "extrude", "grid", "hole", "fillet", "export"
    ]
    assert calls[0] == ("rect", 80, 40, 4)
    assert calls[2] == ("grid", 2, 1, 50, 0)
    assert calls[4] == ("fillet", plate, 1, "top")
    assert result["output"] == str(output.resolve())
    assert result["bytes"] == 24


def test_invalid_extension_rejected_before_import(tmp_path):
    with pytest.raises(ValueError, match=".glb"):
        export_bracket(tmp_path / "bracket.obj", 80, 40, 6, 6.6, 50)

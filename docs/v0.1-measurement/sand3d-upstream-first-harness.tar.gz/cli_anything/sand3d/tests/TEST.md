# Test plan

Runtime checks are deferred to the outer Linux packaging workflow. No results are claimed here.

## Inventory

- `test_core.py`: one source-level recipe test and one invalid extension test, using a controlled fake Sand3D module.
- `test_full_e2e.py`: installed command help and default/JSON bracket exports against the real backend.

## Real workflow

Install upstream Sand3D and this CLI in the same Linux environment. Run `cli-anything-sand3d --json bracket -o <temp>/bracket.glb`; verify the file exists, the GLB header has version 2 and matching length, the first chunk is JSON, and the CLI's byte count and path agree with the file. Repeat with the default output name in a disposable directory.

Run with `CLI_ANYTHING_FORCE_INSTALLED=1` to require the console entrypoint. Expected runtime command: `python -m pytest cli_anything/sand3d/tests -v -s`.

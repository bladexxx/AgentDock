"""The recipe in Sand3D's docs/examples/bracket.py, with GLB export."""

from pathlib import Path
import struct


def export_bracket(output: Path, w: float, d: float, t: float,
                   hole_d: float, pitch: float) -> dict:
    """Build the upstream bracket and export it with Sand3D's native exporter."""
    output = Path(output).expanduser().resolve()
    if output.suffix.lower() != ".glb":
        raise ValueError("output must have a .glb extension")
    if not output.parent.is_dir():
        raise ValueError(f"output directory does not exist: {output.parent}")

    import sand3d as s3d

    # Follow docs/examples/bracket.py exactly; the example is not distributed
    # as an importable module with the installed sand3d package.
    plate = s3d.extrude("plate", s3d.rect(w, d, r=4), t)
    s3d.hole(plate, hole_d, on=s3d.grid(2, 1, pitch, 0))
    s3d.fillet(plate, 1, edges="top")
    s3d.export(plate, str(output))

    size = output.stat().st_size
    with output.open("rb") as glb:
        header = glb.read(12)
    if len(header) != 12 or header[:4] != b"glTF":
        raise RuntimeError(f"Sand3D did not write a GLB: {output}")
    version, declared_size = struct.unpack("<II", header[4:])
    if version != 2 or declared_size != size or size <= 20:
        raise RuntimeError(f"Sand3D wrote an invalid GLB header: {output}")

    return {
        "output": str(output),
        "format": "glb",
        "bytes": size,
        "dimensions_mm": {
            "width": w, "depth": d, "thickness": t,
            "hole_diameter": hole_d, "pitch": pitch,
        },
    }

# Sand3D bracket harness

Source: `docs/examples/bracket.py` in the pinned Sand3D checkout. The example creates an 80 × 40 × 6 mm rounded plate, cuts two 6.6 mm holes at 50 mm pitch, and fillets the top edges by 1 mm. Sand3D's public verbs build Blender geometry; `s3d.export` writes the GLB through Blender's glTF exporter. No independent geometry or GLB writer is used.

The only operation is one-shot `bracket`. Each process starts a fresh Sand3D scene and exports to `bracket.glb` or a specified `.glb` path. The CLI checks the GLB header and emits either a human line or JSON. There is no project data model to persist for this milestone.

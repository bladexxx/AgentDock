# CLI-Anything Sand3D

Export the upstream Sand3D bracket example as a GLB with one headless command.

Install this harness alongside Sand3D in a Python 3.11 or 3.13 environment with its supported `bpy` dependency. From `agent-harness`, install with `pip install .`; the parent Sand3D source can be installed separately with `pip install ../` in an offline prepared environment.

```bash
cli-anything-sand3d --json bracket --output /tmp/bracket.glb
```

Without `--output`, the command writes `bracket.glb` in the current directory. JSON output contains the absolute output path, format, byte size, and example dimensions in millimetres. The command uses `s3d.empty_scene`, the exact modeling calls from `docs/examples/bracket.py`, and `s3d.export`. It checks the GLB 2.0 header before reporting success. It has no saved session or REPL.

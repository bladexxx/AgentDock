---
name: cli-anything-sand3d
description: Export the upstream Sand3D bracket example to a real GLB with a one-shot CLI.
---

# CLI-Anything Sand3D

Use `cli-anything-sand3d` to build the bracket defined by Sand3D's `docs/examples/bracket.py` and export it through `s3d.export`.

## Prerequisites

Install this harness, Sand3D, and the supported `bpy` dependency in Python 3.11 or 3.13 on Linux. The harness installs the `cli-anything-sand3d` console command. Its supported Python versions follow Sand3D's package metadata.

## Command

```bash
cli-anything-sand3d --json bracket --output /tmp/bracket.glb
```

`bracket` is the sole task. `--output` defaults to `bracket.glb` in the current directory and must have a `.glb` suffix. The command creates parent directories, exports a real GLB, and checks its header. `--json` is a global option placed before `bracket`.

The bracket is an 80 × 40 × 6 mm plate with rounded profile corners, two 6.6 mm holes at 50 mm pitch, and a 1 mm top fillet.

## Output

With `--json`, stdout is one JSON object with `output` (absolute path), `format` (`glb`), `bytes` (file size), and `dimensions_mm`. Without it, stdout is a short success line. Errors go to stderr with a nonzero exit status. Check the exit status before using the file.

## Examples

```bash
cli-anything-sand3d bracket
cli-anything-sand3d --json bracket --output /tmp/bracket.glb
```

## Version

0.1.0
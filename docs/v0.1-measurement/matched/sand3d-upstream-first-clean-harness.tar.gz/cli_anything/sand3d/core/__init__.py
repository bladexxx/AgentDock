"""Bracket export operation."""

"""Build the upstream bracket and export it through Sand3D."""

from pathlib import Path
import struct


DIMENSIONS_MM = {"width": 80, "depth": 40, "thickness": 6, "hole_diameter": 6.6, "hole_pitch": 50}


def verify_glb(path: Path) -> int:
    """Return file size only for a complete GLB 2.0 container."""
    size = path.stat().st_size
    if size < 20:
        raise ValueError("Sand3D export produced an incomplete GLB")
    with path.open("rb") as stream:
        magic, version, declared_size, json_size, chunk_type = struct.unpack("<4sIIII", stream.read(20))
    if magic != b"glTF" or version != 2 or declared_size != size or chunk_type != 0x4E4F534A or json_size == 0:
        raise ValueError("Sand3D export produced an invalid GLB header")
    return size


def export_bracket(output: Path) -> dict:
    """Use the calls and dimensions in docs/examples/bracket.py."""
    if output.suffix.lower() != ".glb":
        raise ValueError("output must end in .glb")
    output = output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    import sand3d as s3d

    s3d.empty_scene()
    plate = s3d.extrude("plate", s3d.rect(80, 40, r=4), 6)
    s3d.hole(plate, 6.6, on=s3d.grid(2, 1, 50, 0))
    s3d.fillet(plate, 1, edges="top")
    s3d.export(plate, str(output))
    size = verify_glb(output)
    return {"output": str(output), "format": "glb", "bytes": size, "dimensions_mm": DIMENSIONS_MM}

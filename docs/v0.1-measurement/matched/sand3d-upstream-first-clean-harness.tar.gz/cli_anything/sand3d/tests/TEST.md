# Test plan

Runtime checks are deferred to the outer Linux amd64 workflow for this paired generation. In a prepared Python 3.11 or 3.13 environment with Sand3D and `bpy` installed:

1. Install the harness and invoke `cli-anything-sand3d --help` from outside the source tree.
2. Run `cli-anything-sand3d --json bracket --output /tmp/bracket.glb` and parse its single JSON stdout object.
3. Confirm the output is a GLB 2.0 container: `glTF` magic, declared length equal to file size, and a JSON first chunk. Inspect the glTF JSON for a nonempty mesh.
4. Run from another directory without `--output` and confirm `bracket.glb` is written there.
5. Check a non-`.glb` path fails with a clear error and nonzero exit status.

"""CLI-Anything interface to Sand3D's bracket example."""

"""Small, stateless CLI for Sand3D's upstream bracket example."""

import json
from pathlib import Path

import click

from cli_anything.sand3d.core.bracket import export_bracket


@click.group()
@click.option("--json", "json_output", is_flag=True, help="Print a machine-readable summary.")
@click.pass_context
def main(ctx: click.Context, json_output: bool) -> None:
    """Export the upstream Sand3D bracket as a real GLB."""
    ctx.ensure_object(dict)
    ctx.obj["json_output"] = json_output


@main.command()
@click.option("--output", type=click.Path(path_type=Path, dir_okay=False), default=Path("bracket.glb"),
              show_default=True, help="Destination GLB file.")
@click.pass_context
def bracket(ctx: click.Context, output: Path) -> None:
    """Build the example plate with two holes and a top fillet."""
    try:
        result = export_bracket(output)
    except (OSError, RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    if ctx.obj["json_output"]:
        click.echo(json.dumps(result, sort_keys=True))
    else:
        click.echo(f"Wrote {result['output']} ({result['bytes']} bytes)")


if __name__ == "__main__":
    main()

# Sand3D bracket CLI

This CLI exports the upstream `docs/examples/bracket.py` model as a GLB using
Sand3D's own modeling verbs and `s3d.export`. It runs once per invocation and
keeps no session state.

## Installation

Install the pinned Sand3D source and its supported `bpy` dependency, then install
this harness from `sand3d/agent-harness` with `pip install .`. Sand3D supports
Python 3.11 with bpy 4.5 and Python 3.13 with bpy 5.2.

## Usage

```bash
cli-anything-sand3d --json bracket --output /tmp/bracket.glb
cli-anything-sand3d bracket                 # writes ./bracket.glb
```

The JSON result has `output` (absolute path), `format` (`glb`), and `bytes`.
An invalid extension or failed export exits nonzero. The command validates the
GLB magic, version, and declared file length before reporting success.

## Runtime verification

In a supported Linux environment with Sand3D and bpy installed, run the JSON
command above and inspect the resulting GLB with an independent parser. This
paired-generation trial does not execute the application or install packages.

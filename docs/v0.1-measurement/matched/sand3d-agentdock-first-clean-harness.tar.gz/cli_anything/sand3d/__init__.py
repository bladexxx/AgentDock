"""CLI-Anything adapter for Sand3D's bracket example."""

"""Small headless CLI for the upstream Sand3D bracket example."""

import json
from contextlib import redirect_stdout
from pathlib import Path
import sys

import click

from cli_anything.sand3d.core.bracket import export_bracket


@click.group()
@click.option("--json", "json_output", is_flag=True, help="Print a JSON summary.")
@click.pass_context
def cli(ctx, json_output):
    """Build Sand3D's bracket example as a GLB."""
    ctx.ensure_object(dict)
    ctx.obj["json_output"] = json_output


@cli.command()
@click.option(
    "--output", "output_path", type=click.Path(path_type=Path, dir_okay=False),
    default=Path("bracket.glb"), show_default=True,
    help="Destination GLB path.",
)
@click.pass_context
def bracket(ctx, output_path):
    """Export the 80 x 40 x 6 mm two-hole bracket to a real GLB."""
    try:
        with redirect_stdout(sys.stderr):
            summary = export_bracket(output_path)
    except (ImportError, OSError, RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc
    if ctx.obj["json_output"]:
        click.echo(json.dumps(summary, sort_keys=True))
    else:
        click.echo(f"Wrote {summary['output']} ({summary['bytes']} bytes)")


if __name__ == "__main__":
    cli()

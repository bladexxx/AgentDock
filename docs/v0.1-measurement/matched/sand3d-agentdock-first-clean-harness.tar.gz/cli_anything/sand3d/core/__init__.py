"""Bracket construction and GLB validation."""

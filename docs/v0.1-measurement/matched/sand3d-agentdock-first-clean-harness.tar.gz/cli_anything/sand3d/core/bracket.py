"""The upstream docs/examples/bracket.py recipe and native export."""

from pathlib import Path
import struct


def export_bracket(output: Path) -> dict:
    """Build the upstream bracket and export a real GLB with Sand3D."""
    import sand3d as s3d

    output = Path(output).expanduser().resolve()
    if output.suffix.lower() != ".glb":
        raise ValueError("output path must end in .glb")
    output.parent.mkdir(parents=True, exist_ok=True)

    # docs/examples/bracket.py: w=80, d=40, t=6, hole_d=6.6, pitch=50.
    plate = s3d.extrude("plate", s3d.rect(80, 40, r=4), 6)
    s3d.hole(plate, 6.6, on=s3d.grid(2, 1, 50, 0))
    s3d.fillet(plate, 1, edges="top")
    s3d.export(plate, str(output))

    with output.open("rb") as stream:
        header = stream.read(12)
    if len(header) != 12 or header[:4] != b"glTF":
        raise RuntimeError(f"Sand3D did not write a valid GLB header: {output}")
    version, declared_size = struct.unpack_from("<II", header, 4)
    size = output.stat().st_size
    if version != 2 or declared_size != size or size <= 12:
        raise RuntimeError(f"Sand3D wrote an invalid GLB length or version: {output}")
    return {"output": str(output), "format": "glb", "bytes": size}

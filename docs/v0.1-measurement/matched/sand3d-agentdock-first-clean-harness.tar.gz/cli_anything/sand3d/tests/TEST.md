# Bracket CLI test plan

Runtime checks are deferred to the outer Linux amd64 packaging workflow. This
paired-generation step does not install packages or execute Sand3D.

1. Install the pinned Sand3D source, supported bpy, and this harness.
2. Run `cli-anything-sand3d --json bracket --output /tmp/bracket.glb` from an
   unrelated working directory. Require exit code 0 and exactly one JSON object
   on stdout with the requested absolute output path, `format: glb`, and a
   positive `bytes` count.
3. Independently parse the GLB and check its plate size, two through holes at
   the 50 mm pitch, and top fillet. Inspect the GLB's declared length and
   compare it with the actual file size.
4. Run without `--output` and require `bracket.glb` in the working directory.
5. Pass a non-GLB extension and require a nonzero exit with an explanatory
   stderr message.

No runtime result is claimed here.

---
name: cli-anything-sand3d
description: Export the upstream Sand3D bracket example as a real GLB through a one-shot CLI.
---

# cli-anything-sand3d

This CLI exports the upstream `docs/examples/bracket.py` model as a GLB using Sand3D's own modeling verbs and `s3d.export`. It runs once per invocation and keeps no session state.

## Prerequisites

Install this CLI package alongside the pinned Sand3D source and its supported `bpy` runtime (Python 3.11/bpy 4.5 or Python 3.13/bpy 5.2).

## Command

```bash
cli-anything-sand3d --json bracket --output /tmp/bracket.glb
```

`--output` defaults to `./bracket.glb`. The command constructs the upstream 80 x 40 x 6 mm plate with two 6.6 mm holes 50 mm apart and a 1 mm top fillet. It exports through `s3d.export` and validates the GLB header. It overwrites the requested path.

## Machine output

With `--json`, stdout is one JSON object containing `output` (absolute path), `format` (`glb`), and `bytes` (file size). Check the exit code and inspect stderr on failure. Verify the output file when consuming it.

## Available commands

- `bracket`: Export the 80 x 40 x 6 mm two-hole bracket to a real GLB.


The CLI is stateless and headless. Each invocation constructs one bracket; there is no REPL, project session, or preview command.
from setuptools import find_namespace_packages, setup


setup(
    name="cli-anything-sand3d",
    version="0.1.0",
    description="One-shot Sand3D bracket GLB exporter",
    packages=find_namespace_packages(include=["cli_anything.*"]),
    install_requires=["click>=8,<9", "sand3d"],
    package_data={"cli_anything.sand3d": ["skills/*.md"]},
    entry_points={
        "console_scripts": [
            "cli-anything-sand3d=cli_anything.sand3d.sand3d_cli:cli",
        ]
    },
)

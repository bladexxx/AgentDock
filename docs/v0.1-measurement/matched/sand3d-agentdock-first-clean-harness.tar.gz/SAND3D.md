# Sand3D bracket harness

Sand3D exposes modeling verbs directly through its Python API. Its
`docs/examples/bracket.py` builds a rounded 80 x 40 x 6 mm plate, drills two
6.6 mm holes at a 50 mm pitch, and fillets the top edges by 1 mm. The source
`assembly.export` selects the GLB writer for `.glb` and invokes Blender's glTF
exporter. This harness calls those same verbs in a fresh process, writes one
GLB, and checks its binary header before emitting a summary.

The CLI has one command, `bracket`; `--output` defaults to `bracket.glb` in the
working directory. `--json` is a root option. No persisted model or session is
needed because each invocation builds the complete example.

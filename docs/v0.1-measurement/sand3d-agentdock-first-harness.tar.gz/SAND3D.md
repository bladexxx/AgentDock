# Sand3D bracket harness

## Source analysis

- Target: `sand3d/docs/examples/bracket.py`, using Sand3D's public Python API.
- The example extrudes a rounded 80 × 40 mm plate to 6 mm, cuts two 6.6 mm through holes at 50 mm pitch, then fillets the named top edges by 1 mm.
- `sand3d.assembly.export(root, path)` handles `.glb` through Blender's glTF exporter and scales Sand3D's default millimetres to metres. This is the real output backend.
- The upstream repository supplies a Python library rather than a console command. A fresh Python process is sufficient for each independent bracket build.

## Command design

`cli-anything-sand3d [--json] bracket [-o PATH]` builds one bracket and exports it to `bracket.glb` in the current directory by default. The command uses Sand3D verbs directly, checks the GLB container header after export, and reports the absolute output path and size. It has no persistent state or preview surface.

## Runtime requirements

Run in a supported Python environment with upstream `sand3d`, its matching `bpy` wheel, Click, and Blender glTF export support. The AgentDock Linux workflow supplies and verifies these dependencies. No upstream source files are modified.

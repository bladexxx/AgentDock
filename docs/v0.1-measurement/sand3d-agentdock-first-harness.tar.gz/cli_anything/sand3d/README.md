# CLI-Anything Sand3D

One-shot, headless CLI for the upstream bracket example. It calls Sand3D's `rect`, `extrude`, `grid`, `hole`, `fillet`, and `export` verbs to write a real GLB.

## Requirements

Use Python 3.11 with `bpy` 4.5 or Python 3.13 with `bpy` 5.2, plus upstream Sand3D and Click. Install the harness from `agent-harness` with `pip install .` in an environment where Sand3D's supported dependencies are available. AgentDock packages these in Linux.

## Usage

```bash
cli-anything-sand3d bracket
cli-anything-sand3d --json bracket -o /tmp/bracket.glb
```

The default output is `./bracket.glb`. `--json` prints the absolute output path, GLB size, format, and bracket dimensions. A failed export exits nonzero and writes an error to stderr. Existing output at the chosen path is replaced.

## Verification

After installation in the Linux runtime, run `CLI_ANYTHING_FORCE_INSTALLED=1 python -m pytest cli_anything/sand3d/tests -v -s` from `agent-harness`. The E2E test invokes the installed console command and validates a real GLB. AgentDock's outer verifier checks the exported geometry separately.

"""Build the documented bracket with Sand3D and export a real GLB."""

from pathlib import Path
import struct


def verify_glb(path: Path) -> int:
    """Check the GLB container header and return the file size in bytes."""
    size = path.stat().st_size
    with path.open("rb") as stream:
        header = stream.read(12)
    if len(header) != 12:
        raise ValueError(f"Sand3D produced an incomplete GLB: {path}")
    magic, version, declared_size = struct.unpack("<4sII", header)
    if magic != b"glTF" or version != 2 or declared_size != size or size <= 20:
        raise ValueError(f"Sand3D produced an invalid GLB container: {path}")
    return size


def export_bracket(output: Path) -> dict:
    """Follow docs/examples/bracket.py and export its plate through Sand3D."""
    import sand3d as s3d

    output = output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    plate = s3d.extrude("plate", s3d.rect(80, 40, r=4), 6)
    s3d.hole(plate, 6.6, on=s3d.grid(2, 1, 50, 0))
    s3d.fillet(plate, 1, edges="top")
    s3d.export(plate, str(output))

    return {
        "output": str(output),
        "format": "glb",
        "bytes": verify_glb(output),
        "part": "bracket",
        "width_mm": 80,
        "depth_mm": 40,
        "thickness_mm": 6,
        "hole_diameter_mm": 6.6,
        "hole_pitch_mm": 50,
    }

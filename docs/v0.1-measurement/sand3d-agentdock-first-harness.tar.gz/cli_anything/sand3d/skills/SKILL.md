---
name: cli-anything-sand3d
description: Generate the upstream Sand3D bracket example as a real GLB with a one-shot CLI.
---

# CLI-Anything Sand3D bracket

Build the documented Sand3D bracket in a fresh process and export it through `s3d.export`. Sand3D and its supported `bpy` wheel are required in the runtime.

## Command

```bash
cli-anything-sand3d bracket
cli-anything-sand3d --json bracket -o /absolute/path/bracket.glb
```

`bracket` produces the upstream 80 × 40 × 6 mm rounded plate with two 6.6 mm through holes at 50 mm pitch and a 1 mm top-edge fillet. The default path is `./bracket.glb`. Use `-o` or `--output` for another `.glb` path. An existing file at that path is replaced.

## Agent use

Place `--json` before `bracket` for a machine-readable summary containing the absolute `output` path, `format`, `bytes`, and dimensions. Check the process exit status, parse stdout only on success, and inspect stderr on failure. The command verifies the GLB container header after Sand3D exports it.

The CLI has no session, REPL, or preview mode. See the packaged README for runtime requirements and deferred E2E test instructions.
"""Stateless command-line entry point for Sand3D's bracket example."""

import json
from contextlib import redirect_stdout
from pathlib import Path
import sys

import click

from cli_anything.sand3d.core.bracket import export_bracket


@click.group()
@click.option("--json", "json_output", is_flag=True, help="Print a JSON summary.")
@click.pass_context
def cli(ctx: click.Context, json_output: bool) -> None:
    """Build Sand3D's documented bracket as a GLB file."""
    ctx.ensure_object(dict)
    ctx.obj["json_output"] = json_output


@cli.command()
@click.option(
    "-o", "--output", type=click.Path(path_type=Path, dir_okay=False),
    default=Path("bracket.glb"), show_default=True,
    help="GLB output path.",
)
@click.pass_context
def bracket(ctx: click.Context, output: Path) -> None:
    """Export the 80 × 40 × 6 mm two-hole bracket."""
    if output.suffix.lower() != ".glb":
        raise click.BadParameter("output must end in .glb", param_hint="--output")
    try:
        # Blender's exporter may print progress; keep stdout parseable in JSON mode.
        with redirect_stdout(sys.stderr):
            summary = export_bracket(output)
    except (OSError, RuntimeError, ValueError, ImportError) as exc:
        raise click.ClickException(str(exc)) from exc
    if ctx.obj["json_output"]:
        click.echo(json.dumps(summary, sort_keys=True))
    else:
        click.echo(f"Wrote {summary['output']} ({summary['bytes']} bytes)")


def main() -> None:
    cli()

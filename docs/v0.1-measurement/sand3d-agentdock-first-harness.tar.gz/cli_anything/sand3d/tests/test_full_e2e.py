import json
import os
import shutil
import struct
import subprocess


def _resolve_cli(name):
    path = shutil.which(name)
    if path:
        return [path]
    if os.environ.get("CLI_ANYTHING_FORCE_INSTALLED") == "1":
        raise RuntimeError(f"{name} is not installed")
    raise RuntimeError(f"Install the harness before running E2E tests: {name}")


def test_installed_bracket_exports_real_glb(tmp_path):
    output = tmp_path / "bracket.glb"
    result = subprocess.run(
        _resolve_cli("cli-anything-sand3d") + ["--json", "bracket", "-o", str(output)],
        capture_output=True, text=True, check=True,
    )
    summary = json.loads(result.stdout)
    data = output.read_bytes()
    assert summary["output"] == str(output)
    assert summary["bytes"] == len(data)
    assert summary["format"] == "glb"
    assert data[:4] == b"glTF"
    assert struct.unpack_from("<I", data, 8)[0] == len(data)
    chunk_size, chunk_type = struct.unpack_from("<I4s", data, 12)
    assert chunk_type == b"JSON"
    document = json.loads(data[20:20 + chunk_size].decode("utf-8"))
    assert document["meshes"]
    print(f"GLB: {output} ({len(data)} bytes)")

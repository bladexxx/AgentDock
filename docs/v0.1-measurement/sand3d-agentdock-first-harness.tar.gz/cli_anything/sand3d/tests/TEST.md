# Test plan

## Inventory

- `test_core.py`: 2 unit tests for GLB header acceptance and rejection.
- `test_full_e2e.py`: 1 installed-command test for JSON output and a real GLB export.

## Unit plan

`verify_glb` accepts a valid version 2 container header whose declared length matches the file and rejects a malformed header. These tests use synthetic bytes and do not run Sand3D.

## E2E plan

Invoke `cli-anything-sand3d --json bracket -o <temporary path>` through the installed console entry point. Parse the JSON summary, check the output path and size, and independently inspect the GLB header and first JSON chunk for a mesh. The AgentDock outer verifier will inspect the geometry. No runtime result is recorded yet because this generation invocation excludes upstream execution and package installation.

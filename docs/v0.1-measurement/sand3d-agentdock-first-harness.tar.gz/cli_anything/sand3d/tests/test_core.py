import struct

import pytest

from cli_anything.sand3d.core.bracket import verify_glb


def test_verify_glb_accepts_matching_header(tmp_path):
    path = tmp_path / "model.glb"
    path.write_bytes(struct.pack("<4sII", b"glTF", 2, 24) + b"x" * 12)
    assert verify_glb(path) == 24


def test_verify_glb_rejects_wrong_length(tmp_path):
    path = tmp_path / "model.glb"
    path.write_bytes(struct.pack("<4sII", b"glTF", 2, 25) + b"x" * 12)
    with pytest.raises(ValueError, match="invalid GLB"):
        verify_glb(path)
